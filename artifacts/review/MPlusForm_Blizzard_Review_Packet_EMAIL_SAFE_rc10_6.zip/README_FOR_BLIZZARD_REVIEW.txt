# MPlusForm WoW Add-On + Local Sync Review Packet

This packet is intended for a compliance/safety review question to Blizzard.

## Project Summary

MPlusForm is a World of Warcraft Mythic+ post-run telemetry/reputation add-on.
It records Mythic+ run metadata through normal WoW Lua add-on APIs and writes it
to the standard SavedVariables file. A separate local Windows sync process reads
only normal WoW files from disk and uploads run evidence to the user's private
MPlusForm server through a local SSH tunnel.

## User Question For Blizzard

Could Blizzard confirm whether this design appears compliant with the World of
Warcraft UI Add-On Development Policy and the Blizzard EULA, or point out any
parts that should be removed before use?

The user specifically wants to avoid anything that could be considered botting,
automation, hacking, memory reading, client modification, or prohibited
third-party software.

## Included Source Files

- `addon/MPlusForm/MPlusForm.lua`
- `addon/MPlusForm/MPlusForm.toc`
- `addon/MPlusForm/Data/Snapshot.lua`
- `sync/mplusform_sync_service.py`
- `windows/install_sync_task.ps1`
- `windows/status.ps1`
- `WOW_COMPLIANCE_CHECKLIST_RU.txt`
- `PRIVACY_NOTICE_DRAFT_RU.txt`
- `SYNC_PAYLOAD_CONTRACT_RU.txt`
- `SHA256SUMS.txt`

## Important Compliance Notes

- The add-on uses normal Lua add-on APIs and standard SavedVariables.
- The add-on does not cast spells, target units, interact with units, click
  buttons, run macros, press keys, or automate character control.
- The add-on does not modify the WoW client.
- The add-on does not use hidden or obfuscated code.
- The Windows sync does not read WoW process memory.
- The Windows sync does not use DLL injection, hooks, OpenProcess,
  ReadProcessMemory, WriteProcessMemory, CreateRemoteThread, SendInput,
  keyboard automation, or mouse automation.
- The Windows sync is configured not to inspect the WoW process list.
- The Windows sync reads only:
  - `WTF/.../SavedVariables/MPlusForm.lua`
  - `_retail_/Logs/WoWCombatLog.txt`
- Network access is limited to uploading telemetry to the user's own local
  endpoint, usually `http://127.0.0.1:8015` through an SSH tunnel.
- The public in-game tooltip is disabled in this build.
- Server-approved snapshots are downloaded back into
  `Interface/AddOns/MPlusForm/Data/Snapshot.lua`.

## Local Sync Purpose

The sync process exists because SavedVariables are only flushed by WoW at normal
UI save points such as reload/logout. The sync also tails `WoWCombatLog.txt` to
validate that a recorded Mythic+ run actually happened and to avoid trusting
manually edited SavedVariables as public truth.

## What This Packet Does Not Include

- No Battle.net credentials.
- No game account data.
- No private SSH keys.
- No server tokens.
- No user's SavedVariables.
- No combat logs.
- No compiled executable is required for review; the sync source is included.

