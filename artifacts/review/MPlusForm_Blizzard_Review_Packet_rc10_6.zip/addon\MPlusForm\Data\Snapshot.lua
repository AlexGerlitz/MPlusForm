MPlusFormSnapshotMeta = MPlusFormSnapshotMeta or { version = 0, generatedAt = 0, region = "EU", profiles = 0 }
MPlusFormSnapshot = MPlusFormSnapshot or {}
