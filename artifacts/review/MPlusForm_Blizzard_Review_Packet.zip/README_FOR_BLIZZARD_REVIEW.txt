MPlusForm WoW Add-On + Local Sync Review Packet
================================================

Purpose
-------

This packet is intended for a World of Warcraft add-on compliance/safety review
question to Blizzard.

MPlusForm is a Mythic+ post-run telemetry and reputation add-on. It records
Mythic+ run metadata through normal World of Warcraft Lua add-on APIs and writes
that metadata to the standard SavedVariables file. A separate local Windows
sync process reads normal World of Warcraft files from disk and uploads
post-run evidence to the user's private MPlusForm server through a local
endpoint, usually http://127.0.0.1:8015 over an SSH tunnel.

Question for Blizzard
---------------------

Could Blizzard confirm whether this design appears compliant with the World of
Warcraft UI Add-On Development Policy and the Blizzard EULA, or point out any
parts that should be removed before use?

The user specifically wants to avoid anything that could be considered botting,
automation, hacking, memory reading, client modification, prohibited data
mining, or prohibited third-party software.

Included Files
--------------

- source/addon_MPlusForm_lua_source.txt
- source/addon_MPlusForm_toc_source.txt
- source/addon_Data_Snapshot_lua_source.txt
- source/sync_mplusform_sync_service_python_source.txt
- source/windows_install_sync_task_powershell_source.txt
- source/windows_status_powershell_source.txt
- WOW_COMPLIANCE_CHECKLIST.txt
- PRIVACY_NOTICE_DRAFT.txt
- SYNC_PAYLOAD_CONTRACT.txt
- EMAIL_BODY_TO_BLIZZARD.txt
- SHA256SUMS.txt

The source file extensions were renamed to plain .txt names only to avoid email
attachment blocking by Gmail. The contents are plain text source code.

Important Compliance Notes
--------------------------

- The add-on uses normal Lua add-on APIs and standard SavedVariables.
- The add-on does not cast spells, target units, interact with units, click
  buttons, run macros, press keys, or automate character control.
- The add-on does not modify the World of Warcraft client.
- The add-on code is not hidden or obfuscated.
- The Windows sync does not read World of Warcraft process memory.
- The Windows sync does not use DLL injection, hooks, OpenProcess,
  ReadProcessMemory, WriteProcessMemory, CreateRemoteThread, SendInput,
  keyboard automation, or mouse automation.
- The Windows sync is configured not to inspect the World of Warcraft process
  list.
- The Windows sync reads only:
  - WTF/.../SavedVariables/MPlusForm.lua
  - _retail_/Logs/WoWCombatLog.txt
- Network access is limited to uploading post-run telemetry to the user's own
  MPlusForm endpoint.
- The public in-game tooltip is disabled in this build.
- Server-approved snapshots are downloaded back into
  Interface/AddOns/MPlusForm/Data/Snapshot.lua.

What This Packet Does Not Include
---------------------------------

- No Battle.net credentials.
- No private SSH keys.
- No server tokens.
- No user SavedVariables.
- No combat logs.
- No compiled executable.
- No DLLs.
